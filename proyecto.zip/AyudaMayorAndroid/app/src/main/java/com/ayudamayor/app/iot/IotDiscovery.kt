package com.ayudamayor.app.iot

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * IotDiscovery — descubre dispositivos IoT en la red WiFi local.
 *
 * Estrategia en dos capas (todo nativo Android, sin librerías externas):
 *
 *  1. NsdManager (mDNS / Bonjour) — descubre servicios estándar:
 *       _http._tcp   → Shelly, ESP-Home, Tasmota, Philips Hue, etc.
 *       _hap._tcp    → HomeKit (Apple)
 *       _miio._udp   → Xiaomi Mi Home
 *       _googlecast._tcp → Chromecast / Google Home
 *
 *  2. Escaneo de red local — recorre el rango /24 de la IP del móvil
 *     y comprueba si el host responde en puertos típicos IoT:
 *       80 (HTTP), 8080, 8888, 5000, 4343, 1883 (MQTT), 8883 (MQTTS)
 *     Si responde en 80/8080 intenta leer la raíz para clasificar el dispositivo.
 *
 * Uso desde NativeBridge:
 *   val discovery = IotDiscovery(context)
 *   discovery.start { jsonResult -> ... }  // callback con JSON
 *   discovery.stop()
 *
 * Respuesta JSON:
 * {
 *   "wifi": { "ssid": "MiRed", "ip": "192.168.1.50", "gateway": "192.168.1.1" },
 *   "devices": [
 *     {
 *       "id": "shelly-abc123",
 *       "name": "Shelly1-ABC123",
 *       "type": "shelly",          // shelly|hue|esp|tasmota|chromecast|generic|xiaomi
 *       "ip": "192.168.1.20",
 *       "port": 80,
 *       "source": "mdns",          // mdns | scan
 *       "services": ["_http._tcp"]
 *     }
 *   ]
 * }
 */
class IotDiscovery(private val context: Context) {

    companion object {
        // Tipos mDNS que buscamos
        private val MDNS_SERVICES = listOf(
            "_http._tcp",
            "_hap._tcp",
            "_miio._udp",
            "_googlecast._tcp",
            "_esphomelib._tcp",
            "_arduino._tcp",
            "_workstation._tcp"
        )

        // Puertos típicos de dispositivos IoT para el escaneo de red
        private val IOT_PORTS = listOf(80, 8080, 8888, 5000, 4343, 1880, 1883)

        // Palabras clave en cabeceras HTTP o cuerpo para identificar el dispositivo
        private val FINGERPRINTS = mapOf(
            "shelly"     to listOf("shelly", "Shelly"),
            "hue"        to listOf("hue bridge", "Philips hue", "IpBridge"),
            "tasmota"    to listOf("tasmota", "Tasmota"),
            "esp"        to listOf("ESP8266", "ESP32", "esphome"),
            "chromecast" to listOf("Chromecast", "eureka"),
            "xiaomi"     to listOf("miio", "xiaomi", "Xiaomi")
        )

        private const val SCAN_TIMEOUT_MS  = 300   // ms por host en el escaneo
        private const val HTTP_TIMEOUT_MS  = 1500  // ms para leer la web del dispositivo
        private const val MAX_SCAN_HOSTS   = 254   // rango /24 completo
    }

    // ────────────────────────────────────────────────────────
    // Estado interno
    // ────────────────────────────────────────────────────────
    private val devices = ConcurrentHashMap<String, JSONObject>()
    private var nsdManager: NsdManager? = null
    private val activeListeners = mutableListOf<NsdManager.DiscoveryListener>()
    private var scanJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ────────────────────────────────────────────────────────
    // API pública
    // ────────────────────────────────────────────────────────

    /**
     * Inicia el descubrimiento. El callback se invoca cada vez que se encuentra
     * o actualiza un dispositivo (puede llamarse varias veces).
     */
    fun start(onUpdate: (String) -> Unit) {
        devices.clear()

        val wifiInfo = getWifiInfo()

        // Emitir inmediatamente con info WiFi (aunque aún sin dispositivos)
        onUpdate(buildResult(wifiInfo))

        // Capa 1: mDNS
        startMdnsDiscovery(wifiInfo, onUpdate)

        // Capa 2: escaneo de red
        val subnet = wifiInfo.optString("subnet")
        if (subnet.isNotEmpty()) {
            startNetworkScan(subnet, wifiInfo, onUpdate)
        }
    }

    /** Detiene todo — llamar cuando el WebView sale de la pantalla IoT */
    fun stop() {
        scanJob?.cancel()
        scope.coroutineContext.cancelChildren()
        nsdManager?.let { mgr ->
            activeListeners.forEach { listener ->
                try { mgr.stopServiceDiscovery(listener) } catch (_: Exception) {}
            }
        }
        activeListeners.clear()
        devices.clear()
    }

    // ────────────────────────────────────────────────────────
    // WiFi info
    // ────────────────────────────────────────────────────────

    fun getWifiInfo(): JSONObject {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wm.connectionInfo
        val dhcp = wm.dhcpInfo

        val rawSsid = info.ssid ?: ""
        val ssid = rawSsid.removeSurrounding("\"") // Android devuelve con comillas

        val ipInt  = info.ipAddress
        val ip     = intToIp(ipInt)
        val gw     = intToIp(dhcp.gateway)
        val mask   = intToIp(dhcp.netmask)
        val subnet = if (ip.isNotEmpty()) ip.substringBeforeLast(".") else ""

        return JSONObject().apply {
            put("ssid",    ssid)
            put("bssid",   info.bssid ?: "")
            put("ip",      ip)
            put("gateway", gw)
            put("netmask", mask)
            put("subnet",  subnet)
            put("rssi",    info.rssi)
        }
    }

    // ────────────────────────────────────────────────────────
    // mDNS (NsdManager)
    // ────────────────────────────────────────────────────────

    private fun startMdnsDiscovery(wifiInfo: JSONObject, onUpdate: (String) -> Unit) {
        nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager

        MDNS_SERVICES.forEach { serviceType ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onStartDiscoveryFailed(st: String, errorCode: Int) {}
                override fun onStopDiscoveryFailed(st: String, errorCode: Int) {}
                override fun onDiscoveryStarted(st: String) {}
                override fun onDiscoveryStopped(st: String) {}
                override fun onServiceLost(info: NsdServiceInfo) {}

                override fun onServiceFound(info: NsdServiceInfo) {
                    resolveService(info, serviceType, wifiInfo, onUpdate)
                }
            }
            activeListeners.add(listener)
            try {
                nsdManager?.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener)
            } catch (_: Exception) {}
        }
    }

    private fun resolveService(
        info: NsdServiceInfo,
        serviceType: String,
        wifiInfo: JSONObject,
        onUpdate: (String) -> Unit
    ) {
        nsdManager?.resolveService(info, object : NsdManager.ResolveListener {
            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {}

            override fun onServiceResolved(info: NsdServiceInfo) {
                val ip   = info.host?.hostAddress ?: return
                val port = info.port
                val name = info.serviceName ?: "Dispositivo"
                val key  = "$ip:$port"

                val existing = devices.getOrDefault(key, JSONObject())
                val services = existing.optJSONArray("services") ?: JSONArray()
                if ((0 until services.length()).none { services.getString(it) == serviceType }) {
                    services.put(serviceType)
                }

                val deviceType = detectTypeFromName(name) ?: detectTypeFromService(serviceType)

                val device = JSONObject().apply {
                    put("id",       sanitizeId(name))
                    put("name",     name)
                    put("type",     deviceType)
                    put("ip",       ip)
                    put("port",     port)
                    put("source",   "mdns")
                    put("services", services)
                }
                devices[key] = device

                // Enriquecer con fingerprint HTTP en background
                scope.launch {
                    enrichWithHttp(device)
                    onUpdate(buildResult(wifiInfo))
                }
            }
        })
    }

    // ────────────────────────────────────────────────────────
    // Escaneo de red local
    // ────────────────────────────────────────────────────────

    private fun startNetworkScan(subnet: String, wifiInfo: JSONObject, onUpdate: (String) -> Unit) {
        scanJob = scope.launch {
            val jobs = (1..MAX_SCAN_HOSTS).map { i ->
                async {
                    val host = "$subnet.$i"
                    if (isReachable(host)) {
                        checkIotPorts(host, wifiInfo, onUpdate)
                    }
                }
            }
            jobs.awaitAll()
            onUpdate(buildResult(wifiInfo)) // Emisión final tras escaneo completo
        }
    }

    private fun isReachable(host: String): Boolean = try {
        InetAddress.getByName(host).isReachable(SCAN_TIMEOUT_MS)
    } catch (_: Exception) { false }

    private suspend fun checkIotPorts(
        host: String,
        wifiInfo: JSONObject,
        onUpdate: (String) -> Unit
    ) {
        for (port in IOT_PORTS) {
            val key = "$host:$port"
            if (devices.containsKey(key)) continue // ya detectado por mDNS

            val open = withContext(Dispatchers.IO) {
                try {
                    val socket = java.net.Socket()
                    socket.connect(java.net.InetSocketAddress(host, port), SCAN_TIMEOUT_MS)
                    socket.close()
                    true
                } catch (_: Exception) { false }
            }

            if (open) {
                val device = JSONObject().apply {
                    put("id",       "scan-${host.replace('.', '-')}-$port")
                    put("name",     "Dispositivo $host")
                    put("type",     "generic")
                    put("ip",       host)
                    put("port",     port)
                    put("source",   "scan")
                    put("services", JSONArray())
                }

                // Intentar fingerprint HTTP
                if (port == 80 || port == 8080) {
                    enrichWithHttp(device)
                }

                devices[key] = device
                onUpdate(buildResult(wifiInfo))
                break // Basta con encontrar un puerto abierto por host
            }
        }
    }

    // ────────────────────────────────────────────────────────
    // Fingerprinting HTTP
    // ────────────────────────────────────────────────────────

    private suspend fun enrichWithHttp(device: JSONObject) = withContext(Dispatchers.IO) {
        val ip   = device.optString("ip")
        val port = device.optInt("port", 80)
        val url  = if (port == 80) "http://$ip/" else "http://$ip:$port/"

        try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = HTTP_TIMEOUT_MS
            conn.readTimeout    = HTTP_TIMEOUT_MS
            conn.requestMethod  = "GET"
            conn.instanceFollowRedirects = true

            val headers = conn.headerFields.entries
                .joinToString(" ") { (k, v) -> "${k ?: ""}:${v.joinToString()}" }
                .lowercase()

            val body = try {
                conn.inputStream.bufferedReader().readText().take(2048).lowercase()
            } catch (_: Exception) { "" }

            conn.disconnect()

            val combined = "$headers $body"

            for ((type, keywords) in FINGERPRINTS) {
                if (keywords.any { combined.contains(it.lowercase()) }) {
                    device.put("type", type)
                    // Intentar mejorar el nombre con info del dispositivo
                    val betterName = extractDeviceName(body, type)
                    if (betterName != null) device.put("name", betterName)
                    break
                }
            }
        } catch (_: Exception) {
            // Host no responde en HTTP — se queda como generic
        }
    }

    private fun extractDeviceName(body: String, type: String): String? {
        return when (type) {
            "shelly" -> {
                // Shelly responde en /shelly con {"id":"shellyplug-s-abc123",...}
                Regex("\"id\"\\s*:\\s*\"([^\"]+)\"").find(body)?.groupValues?.get(1)
            }
            "tasmota" -> {
                Regex("<title>([^<]+)</title>").find(body)?.groupValues?.get(1)
            }
            else -> null
        }
    }

    // ────────────────────────────────────────────────────────
    // Helpers de clasificación
    // ────────────────────────────────────────────────────────

    private fun detectTypeFromName(name: String): String? {
        val lc = name.lowercase()
        return when {
            lc.contains("shelly")     -> "shelly"
            lc.contains("hue")        -> "hue"
            lc.contains("tasmota")    -> "tasmota"
            lc.contains("esp")        -> "esp"
            lc.contains("chromecast") -> "chromecast"
            lc.contains("xiaomi") || lc.contains("miio") -> "xiaomi"
            lc.contains("esphome")    -> "esp"
            else -> null
        }
    }

    private fun detectTypeFromService(service: String) = when {
        service.contains("googlecast") -> "chromecast"
        service.contains("hap")        -> "homekit"
        service.contains("miio")       -> "xiaomi"
        service.contains("esphome")    -> "esp"
        else                           -> "generic"
    }

    private fun sanitizeId(name: String) =
        name.lowercase().replace(Regex("[^a-z0-9]+"), "-")

    // ────────────────────────────────────────────────────────
    // Construcción del resultado JSON
    // ────────────────────────────────────────────────────────

    private fun buildResult(wifiInfo: JSONObject): String {
        val arr = JSONArray()
        devices.values.forEach { arr.put(it) }
        return JSONObject().apply {
            put("wifi",    wifiInfo)
            put("devices", arr)
        }.toString()
    }

    // ────────────────────────────────────────────────────────
    // Utilidades
    // ────────────────────────────────────────────────────────

    private fun intToIp(ip: Int): String {
        if (ip == 0) return ""
        return "${ip and 0xFF}.${ip shr 8 and 0xFF}.${ip shr 16 and 0xFF}.${ip shr 24 and 0xFF}"
    }
}
